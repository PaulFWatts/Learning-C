// KIT107 Lab 12: prique
/*
 * Implementation for prique using linked-list
 * Author Julian Dermoudy
 * Version 25/5/18
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dnode.h"
#include "prique.h"

struct prique_int {
	dnode first;
};

/*
 * 'Constructor' for prique
 */
void init_prique(prique *pp)
{
	*pp=(prique)malloc(sizeof(struct prique_int));
	(*pp)->first=NULL;
}

/*
 * Check for emptiness
 * Return true if prique is empty, false otherwise
*/
bool isEmpty(prique p)
{
	return (p->first == NULL);
}

/*
 * Find first item in prique
 * Return value at front of prique
*/
void *front(prique p)
{
	if (isEmpty(p))
	{
		fprintf(stderr,"prique is empty.");
		exit(1);
	}
	
	return getData(p->first);
}

/*
 * Remove front item from prique
*/
void rear(prique p)
{
	if (isEmpty(p))
	{
		fprintf(stderr,"prique is empty.");
		exit(1);
	}
	else
	{
		p->first=getNext(p->first);
		setPrev(p->first,NULL);
	}
}

/*
 * Add item to prique
 * Param o value to be added to prique
*/
void add(prique p,void *o,bool(*greaterThan)(void *,void *))
{
	dnode n,b,c;

	init_dnode(&n,o);

	if (isEmpty(p))
	{
		p->first=n;
	}
	else
	{
		c=p->first;
		b=getPrev(c);
		while ((c!=NULL) && ((*greaterThan)(getData(c),o)))
		{
			b=c;
			c=getNext(c);
		}

		if (b==NULL)
		{
			p->first=n;
		}
		else
		{
			setNext(b,n);
		}
		setPrev(n,b);

		if (c!=NULL)
		{
			setPrev(c,n);
		}
		setNext(n,c);
	}
}

/*
 * Find printable form of prique
 * Return string form of prique for printing etc.
*/
char *toString(prique p,char *(*makePrintable)(void *))
{
	dnode c;
	char *s=(char *)malloc(1000*sizeof(char));
	
	if (isEmpty(p))
		sprintf(s,"<>");
	else
	{
		sprintf(s,"<");
		c=p->first;
		while (c != NULL)
		{
			sprintf(s,"%s%s",s,(*makePrintable)(getData(c)));
			c=getNext(c);
			if (c != NULL)
			{
				s=strcat(s,", ");
			}
		}
		s=strcat(s,">");
	}
	return s;
}


