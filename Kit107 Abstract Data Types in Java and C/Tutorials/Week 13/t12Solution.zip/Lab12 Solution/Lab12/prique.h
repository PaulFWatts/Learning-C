// KIT107 Lab 12: prique
/*
 * Specification for the prique ADT
 * Author Julian Dermoudy
 * Version 25/5/18
*/

#include <stdbool.h>

#ifndef PRIQUE_H
#define PRIQUE_H

struct prique_int;
typedef struct prique_int *prique;

void init_prique(prique *pp);
bool isEmpty(prique p);
void add(prique p, void *o, bool(*greaterThan)(void *, void *));
void *front(prique p);
void rear(prique p);
char *toString(prique p, 
char *(*makePrintable)(void *));

#endif