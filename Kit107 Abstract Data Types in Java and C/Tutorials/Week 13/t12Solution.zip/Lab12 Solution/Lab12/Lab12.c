// KIT107 Lab 12: harness
/*
 * Program to illustrate implementation of prique
 * Author Julian Dermoudy
 * Version 25/5/18
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "prique.h"

bool alphabeticalOrder(void *t1, void *t2)
{
	char *s1=(char *)t1;
	char *s2=(char *)t2;

	return (strcmp(s1,s2) < 0);
}

char *makePrintable(void *t)
{
	return (char *)t;
}

int main(int argc, char *argv[])
{
	prique p;
	char *animals[]={"cat","dog","horse","aardvark","cow","pig"};
	int i;
		
	printf("Building prique...");
	init_prique(&p);
		
	for (i=0;i<6; i++)
	{
		printf("adding %s...",animals[i]);
		add(p,animals[i],alphabeticalOrder);
	}
	printf("done.\n");

	printf("Before removal prique is %s\n",toString(p,makePrintable));
	rear(p);
	printf("After removal prique is %s\n",toString(p,makePrintable));
}
