/*
 * KIT107 Programming 
 * Lab 8: Harness
 *
 * Author: Julian Dermoudy
 * Version 27/4/18
 */

#include "queue.h"
#include <stdlib.h>
#include <stdio.h>

int main(int argc, char *argv[])
{
	queue q;
	int i, n, s;
	int *sp;

	n = rand() % 10 + 1; // how may students?  1-10

	init_queue(&q); // create the queue

	printf("Adding %d students...", n);
	for (i = 1; i <= n; i++)
	{
		s = rand() % 1000000; // get random student ID, i.e. 0-999999
		sp = (int *)malloc(sizeof(int));
		*sp = s;
		printf("[%06d] ", s); // format as 6 digit number with leading zeroes
		add(q, sp); // place student ID in queue
	}
	printf("done.\n");

	printf("Queue is <%s>\n", toString(q, "%06d"));

	printf("Queue is empty? %s\n", isEmpty(q) ? "true" : "false");
	printf("Front is %06d\n", *((int *)(front(q))));
	printf("Removing front item...");
	rear(q);
	printf("done.\n");
	printf("Front is now %06d\n", *((int *)(front(q))));
	printf("Queue is <%s>\n", toString(q, "%06d"));

	getch();
}
