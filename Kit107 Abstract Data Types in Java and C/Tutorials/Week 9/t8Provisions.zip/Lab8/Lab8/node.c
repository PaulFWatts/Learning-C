// KIT107 Lab 8: Node
/*
 * Implementation for Node
 * Author <<YOUR NAME HERE>>
 * Version <<DATE>>>
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include "node.h"


struct node_int {
	void *data;
	node next;
};


/*
* 'Initialiser' for node
*/
void init_node(node *np,void *o)
{
	COMPLETE ME!!!
}

/*
* Getter for data
* Return data field
*/
void *getData(node n)
{
	COMPLETE ME!!!
}

/*
* Getter for next
* Return next field
*/
node getNext(node n)
{
	COMPLETE ME!!!
}

/*
* Setter for data
* Param o value to be placed into the node's data field
*/
void setData(node n,void *o)
{
	COMPLETE ME!!!
}

/*
* Setter for next
* Param o value to be placed into the node's next field
*/
void setNext(node v, node n)
{
	COMPLETE ME!!!
}


