// KIT107 Lab 8: Queue
/*
 * Specification for the Queue ADT
 * Author Julian Dermoudy
 * Version 27/4/2018
*/

#include <stdbool.h>

#ifndef QUEUE_H
#define QUEUE_H

struct queue_int;
typedef struct queue_int *queue;

void init_queue(queue *q);
bool isEmpty(queue q);
void add(queue q,void *i);
void *front(queue q);
void rear(queue q);
char *toString(queue q, char *f);

#endif