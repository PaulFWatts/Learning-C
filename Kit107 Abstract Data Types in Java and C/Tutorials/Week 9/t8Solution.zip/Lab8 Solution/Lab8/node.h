// KIT107 Lab 8: Node
/*
 * Specification for the Node ADT
 * Author Julian Dermoudy
 * Version 27/4/18
*/

#include <stdbool.h>

#ifndef NODE_H
#define NODE_H

struct node_int;
typedef struct node_int *node;

void init_node(node *vp, void *o);
void setData(node v, void *o);
void setNext(node v, node n);
void *getData(node v);
node getNext(node v);

#endif