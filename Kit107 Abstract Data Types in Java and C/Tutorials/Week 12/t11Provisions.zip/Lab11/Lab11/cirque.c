// KIT107 Lab 11: cirque
/*
 * Implementation for cirque using doubly-linked list
 * Author <<Your name here>>
 * Version 17/5/18
 */

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dnode.h"
#include "cirque.h"

struct cirque_int {
	dnode cursor;
};

/*
 * 'Constructor' for cirque
 */
void init_cirque(cirque *p)
{
	COMPLETE ME
}

/*
 * Check for emptiness
 * Return true if cirque is empty, false otherwise
*/
bool isEmpty(cirque p)
{
	COMPLETE ME
}

/*
 * Find current item in cirque, advancing cursor to next
 * Return value under cursor when function is called
*/
void *nextOne(cirque p)
{
	COMPLETE ME
}

/*
 * Remove current item from cirque
*/
void rear(cirque p)
{
	COMPLETE ME
}

/*
 * Add item to cirque in front of cursor
 * Param o value to be added to cirque
*/
void add(cirque p,void *o)
{
	COMPLETE ME
}

/*
 * Find printable form of cirque
 * Return string form of cirque for printing etc.
*/
char *toString(cirque p,char *(*makePrintable)(void *))
{
	dnode c;
	bool done;
	char *s=(char *)malloc(1000*sizeof(char));
	
	if (isEmpty(p))
		sprintf(s,"<>");
	else
	{
		done=false;
		sprintf(s,"<");
		c=p->cursor;
		while ((c != p->cursor) || (! done))
		{
			if (c == p->cursor)
			{
				sprintf(s,"%s[%s]",s,(*makePrintable)(getData(c)));
				done=true;
			}
			else
			{
				sprintf(s,"%s%s",s,(*makePrintable)(getData(c)));
			}
			if (c != getPrev(p->cursor))
			{
				s=strcat(s,", ");
			}
			c=getNext(c);
		}
		s=strcat(s,">");
	}
	return s;
}


